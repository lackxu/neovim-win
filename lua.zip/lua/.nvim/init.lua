-- Plugin Manager
--require'plugins'
require'lsp'
local M = {}

local api = vim.api

function M.init()
  -- Hide The "~" (tilde Symbol) Figure From Start
  api.nvim_command('source ~/.config/nvim/lua/plugins.vim')
  api.nvim_command('au VimEnter * hi NonText guifg=bg')
  api.nvim_command('au VimEnter * hi LineNr guibg=bg')
  api.nvim_command('au VimEnter * hi CursorLineNr guibg=bg')
  require 'zephyr'
  -- for emmet-vim
  -- vim.api.nvim_command('imap <tab> <c-y>,')
  vim.fn.nvim_set_keymap('n', '<A-i>', ':FTermToggle<CR>', { noremap = true, silent = true })
  vim.fn.nvim_set_keymap('t', '<A-i>', '<C-\\><C-n>:FTermToggle<CR>', { noremap = true, silent = true })
end

-- call function

local pbind = require 'plbind'
local vim = vim
local options = setmetatable({}, { __index = { global_local = {},window_local = {} } })

function options:load_options()
  self.global_local = {
    termguicolors  = true;
    mouse          = "nv";
    errorbells     = true;
    visualbell     = true;
    hidden         = true;
    fileformats    = "unix,mac,dos";
    magic          = true;
    virtualedit    = "block";
    encoding       = "utf-8";
    viewoptions    = "folds,cursor,curdir,slash,unix";
    sessionoptions = "curdir,help,tabpages,winsize";
    clipboard      = "unnamedplus";
    wildignorecase = true;
    wildignore     = ".git,.hg,.svn,*.pyc,*.o,*.out,*.jpg,*.jpeg,*.png,*.gif,*.zip,**/tmp/**,*.DS_Store,**/node_modules/**,**/bower_modules/**";
    backup         = false;
    writebackup    = false;
    undofile       = true;
    swapfile       = false;
    --directory      = global.cache_dir .. "swag/";
    --undodir        = global.cache_dir .. "undo/";
    --backupdir      = global.cache_dir .. "backup/";
    --viewdir        = global.cache_dir .. "view/";
    --spellfile      = global.cache_dir .. "spell/en.uft-8.add";
    history        = 2000;
    shada          = "!,'300,<50,@100,s10,h";
    backupskip     = "/tmp/*,$TMPDIR/*,$TMP/*,$TEMP/*,*/shm/*,/private/var/*,.vault.vim";
    smarttab       = true;
    shiftround     = true;
    timeout        = true;
    ttimeout       = true;
    timeoutlen     = 500;
    ttimeoutlen    = 10;
    updatetime     = 100;
    redrawtime     = 1500;
    ignorecase     = true;
    smartcase      = true;
    infercase      = true;
    incsearch      = true;
    wrapscan       = true;
    complete       = ".,w,b,k";
    inccommand     = "split";
    grepformat     = "%f:%l:%c:%m";
    grepprg        = 'rg --hidden --vimgrep --smart-case --';
    breakat        = [[\ \	;:,!?]];
    startofline    = false;
    whichwrap      = "h,l,<,>,[,],~";
    splitbelow     = true;
    splitright     = true;
    switchbuf      = "useopen";
    backspace      = "indent,eol,start";
    diffopt        = "filler,iwhite,internal,algorithm:patience";
    completeopt    = "menu,menuone,noselect,noinsert";
    jumpoptions    = "stack";
    showmode       = false;
    shortmess      = "aoOTIcF";
    --shortmess      = "atI";
    scrolloff      = 0;
    sidescrolloff  = 5;
    foldlevelstart = 99;
    ruler          = false;
    list           = true;
    showtabline    = 0;
    winwidth       = 30;
    winminwidth    = 10;
    pumheight      = 15;
    helpheight     = 12;
    previewheight  = 12;
    showcmd        = false;
    cmdheight      = 2;
    cmdwinheight   = 5;
    equalalways    = false;
    laststatus     = 2;
    display        = "lastline";
    showbreak      = "↳  ";
    listchars      = "tab:»·,nbsp:+,trail:·,extends:→,precedes:←";
    pumblend       = 10;
    winblend       = 10;
  }

  self.bw_local   = {
    synmaxcol      = 2500;
    syntax         = 'on';
    lang           = 'en_US:utf8';
    formatoptions  = "1jcroql";
    textwidth      = 100;
    expandtab      = true;
    tabstop        = 2;
    shiftwidth     = 2;
    softtabstop    = -1;
    autoindent     = true;
    breakindentopt = "shift:2,min:20";
    wrap           = false;
    linebreak      = true;
    number         = true;
    relativenumber = true;
    colorcolumn    = "";
    foldenable     = true;
    foldmethod     = "indent";
    signcolumn     = "no";
    conceallevel   = 2;
    concealcursor  = "niv";
  }

  --if global.is_mac then
    --vim.g.clipboard = {
      --name = "macOS-clipboard",
      --copy = {
        --["+"] = "pbcopy",
        --["*"] = "pbcopy",
      --},
      --paste = {
        --["+"] = "pbpaste",
        --["*"] = "pbpaste",
      --},
      --cache_enabled = 0
    --}
    --vim.g.python_host_prog = '/usr/bin/python'
    --vim.g.python3_host_prog = '/usr/local/bin/python3'
  --end
  vim.g.python_host_prog = '/usr/bin/python'
  vim.g.python3_host_prog = '/usr/local/bin/python3'
  for name, value in pairs(self.global_local) do
    vim.o[name] = value
  end
  pbind.bind_option(self.bw_local)
end
function M.leader_map()
  vim.g.mapleader = " "
  vim.fn.nvim_set_keymap('n',' ','',{noremap = true})
  vim.fn.nvim_set_keymap('x',' ','',{noremap = true})
end
--return options
M.leader_map()
options:load_options()
M.init()
