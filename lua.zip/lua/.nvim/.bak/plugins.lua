-- Auto Load Change
--vim.api.nvim_command('autocmd BufWritePost plugins.lua PackerCompile')

vim.cmd [[packadd packer.nvim]]

local fileType = {'sh', 'zsh', 'bash', 'c', 'cpp', 'lua', 'cmake', 'html', 'markdown', 'racket', 'vim', 'tex', 'py', 'vue', 'html'}

local webFileType = {'html', 'vue', 'xml'}

return require('packer').startup(function()

  -- Packer can manage itself as an optional plugin

  use {'wbthomason/packer.nvim', opt = true}

  -- Simple plugins can be specified as strings

  use '9mm/vim-closer'

  -- Lazy loading:

  -- Load on specific commands

  use {'tpope/vim-dispatch', opt = true, cmd = {'Dispatch', 'Make', 'Focus', 'Start'}}

  -- Load on an autocommand event

  --use {'andymass/vim-matchup', event = 'VimEnter *'}
  use {'andymass/vim-matchup'}

  -- Load on a combination of conditions: specific filetypes or commands

  -- Also run code after load (see the "config" key)

  --use {
    --'w0rp/ale',
    --ft = fileType,
    --cmd = 'ALEEnable',
    --config = 'vim.cmd[[ALEEnable]]'
  --}

  -- Plugins can have dependencies on other plugins

  use {
      'nvim-lua/diagnostic-nvim'
  }

  use {
    'nvim-lua/lsp-status.nvim'
  }

  use {
    'arcticicestudio/nord-vim'
  }


  use {
    'nvim-lua/completion-nvim',
    --requires = {{'hrsh7th/vim-vsnip'}, {'hrsh7th/vim-vsnip-integ'}},
  }

  -- Local plugins can be included

  -- use '~/projects/personal/hover.nvim'

  -- Plugins can have post-install/update hooks

  use {'iamcco/markdown-preview.nvim', run = 'cd app && yarn install', cmd = 'MarkdownPreview', ft = {'md', 'markdown'}}

  use {'glepnir/zephyr-nvim'}

  -- You can specify multiple plugins in a single call

  use {
    'tjdevries/colorbuddy.vim', {'nvim-treesitter/nvim-treesitter', opt = true},
  }

  -- You can alias plugin names

  --use {'dracula/vim', as = 'dracula'}

  use {
    'glepnir/galaxyline.nvim',
    branch = 'main',
    -- your statusline
    config = require'eviline',
    -- some optional icons
    requires = {'kyazdani42/nvim-web-devicons', opt = true}
  }

  use {'lack-xu/vim-cool'}

  --use {'skywind3000/vim-terminal-help'}

  use {
    'neovim/nvim-lspconfig',
  }

  use {
    'nvim-lua/lsp_extensions.nvim',
  }

  use {
    'fratajczak/one-monokai-vim',
    config = function()
      vim.api.nvim_command('let g:monokai_term_italic = 1')
      vim.api.nvim_command('let g:monokai_gui_italic = 1')      
    end,
  }

  --use {
  ----'glepnir/indent-guides.nvim',
  ------ft = fileType,
  ----config = function()
    ----require('indent_guides').options = {
      ----indent_levels = 30;
      ----indent_guide_size = 1;
      ----indent_start_level = 1;
      ----indent_space_guides = false;
      ----indent_tab_guides = true;
      ----indent_pretty_guides = true;
      ----indent_soft_pattern = '\\s';
      ----exclude_filetypes = {'help'}
    ----}
  ----end
  --}

  use 'liuchengxu/space-vim-dark'
  
  use 'kyazdani42/blue-moon'
  
  use 'ajmwagar/vim-deus'

  --use 'stsewd/gx-extended.vim'

  --use {
    --'RRethy/vim-hexokinase',
    --config = vim.api.nvim_command("let g:Hexokinase_highlighters = ['virtual']")
  --}
  
  --use {
    --'datwaft/bubbly.nvim'
  --}

  use {
    'nvim-telescope/telescope.nvim',
    requires = {{'nvim-lua/popup.nvim'}, {'nvim-lua/plenary.nvim'}}
  }

  use {
    'preservim/nerdcommenter',
    --ft = fileType
  }

  use {
    'tpope/vim-surround',
  }

  use {
    'mattn/emmet-vim',
    use {
      'alvan/vim-closetag',
    },
    use {
      'AndrewRadev/tagalong.vim',
    },
    ft = {'html', 'vue', 'xml'}

  }

  use 'numtostr/FTerm.nvim'

  use {
    'joshdick/onedark.vim',
    config = vim.api.nvim_command("let g:onedark_terminal_italics = 1")
  }

  use {
    'neoclide/coc.nvim',
    config = vim.api.nvim_command('source ~/.config/nvim/coc.vim')
  }

  use {
    'machakann/vim-highlightedyank',
    config = vim.api.nvim_command('let g:highlightedyank_highlight_duration = 180')
  }

  use {
    'kyazdani42/nvim-tree.lua',
    config = vim.api.nvim_command('source ~/.config/nvim/lua/nvim-tree.vim')
  } 

end)
