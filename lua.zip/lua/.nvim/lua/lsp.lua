local lsp = require'lspconfig'
--local diagnostic = require'diagnostic'
--local completion = require'completion'
--local lsp_status = require'lsp-status'
--local api = vim.api

--lsp.sumneko_lua.setup{}

--lsp.diagnosticls.setup{
  --cmd = { "diagnostic-languageserver", "--stdio" }
--}

lsp.ccls.setup{}

lsp.vuels.setup{}

lsp.pyls.setup{}

lsp.tsserver.setup{}

lsp.angularls.setup{}

lsp.html.setup{}
